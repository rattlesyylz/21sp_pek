// Cynthia Hong
// 6/2/2021 
// CSE142
// TA: Ana Jojic
// Take-home Assessment #8
//
/* This class represents a Critter of type Vulture. When they move, they go 
North three (3) times, then east three (3) times, then south three (3) times,
then west three (3) times, then repeat. When they fight, Roar if opponent
looks like an ant ("%"); otherwise, pounce. They always appear as black and eat
the first food encountered after being created or after each fight. 
They string "^" (caret) if last move was north, or never has never moved;
">" (greater than) if last move was east; "V" (uppercase V) if last move was south;
"<" (less than) if last move was west. */
 
import java.awt.*;
import java.util.*;

public class Vulture extends Bird {
   private boolean eating; // whether the Vulture still eats or not

   // Constructs a new vulture
   public Vulture() {
      eating = true;
   }

   // Vultures return North three (3) times, then returning east three (3) times,
   // then returning south three (3) times, then returning west three (3) times,
   // then repeat, which is the same as that of Bird.
   public Direction getMove() {
      return super.getMove();
   }
   
   // Vultures eat the first food encountered after being created
   // or after each fight. (returns true). After eating, vultures
   // will become "full" and do not eat any more (returns false) until next fight.      
   public boolean eat() {
      if (eating) {
         eating = false;
         return true;
      } else {
         return false;
      }
   }
   
   // Roar if opponentlooks like an ant ("%"); (returns Attack.ROAR)
   // otherwise, pounce (returns Attack.POUNCE).
   // It is the same of that of Bird. 
   // After fighting, vultures become hungry.
   public Attack fight(String opponent) {
      eating = true;
      return super.fight(opponent);
   }

   // Vultures are always black (returns BLACK)
   public Color getColor() {
      return Color.BLACK;
   }
   
   // Returns "^" (caret) if last move was north, or never has never moved;
   // returns ">" (greater than) if last move was east;
   // returns "V" (uppercase V) if last move was south; 
   // returns "<" (less than) if last move was west.
   // It is the same as that of Bird.
   public String toString() {
      return super.toString();
   }
}
