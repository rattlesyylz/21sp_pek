// Cynthia Hong
// 6/2/2021 
// CSE142
// TA: Ana Jojic
// Take-home Assessment #8
//
/* This class represents a Critter of type Husky. When they move,
they go different direction according to how many step they have gone. 
When they fight, they always pounce. They always appear as yellow. 
They always eat, and always string W. */
 
import java.awt.*;
import java.util.*;

public class Husky extends Critter {
   private int stepCount; // the number of moves that the husky has taken

   // Constructs a new Husky
   public Husky() {
      stepCount = -1; // the first step is counted as zero
   }
   
   // Huskys return center if stepCount could be divided by 11;
   // return west if the stepCount could be divided by 3;
   // return south if the stepCount could be divided by 5;
   // return east if the stepCount could be divided by 7;
   // otherwise return north.
   public Direction getMove() {
      stepCount++;
      if (stepCount % 11 == 0) {
         return Direction.CENTER;
      } else if (stepCount % 3 == 0) {
         return Direction.WEST;
      } else if (stepCount % 5 == 0) {
         return Direction.SOUTH;
      } else if (stepCount % 7 == 0) {
         return Direction.EAST;
      } else {
         return Direction.NORTH;
      }
   }
     
   // Huskys always eat (returns true)
   public boolean eat() {
      return true;
   }

   // Huskys always pounce (returns Attack.POUNCE)
   // Parameters:
   //     String opponent - the String representation of the opponent Critter
   public Attack fight(String opponent) {
      return Attack.POUNCE;
   }

   // Huskys are always yellow (returns YELLOW)
   public Color getColor() {
      return Color.YELLOW;
   }
   
   // Returns capital case letter w
   public String toString() {
      return "W";
   }
}
