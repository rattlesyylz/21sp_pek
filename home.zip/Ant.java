// Cynthia Hong
// 6/2/2021 
// CSE142
// TA: Ana Jojic
// Take-home Assessment #8
//
/* This class represents a Critter of type Ant. When they move, 
if constructed with walkSouth as true, they alternate between south and east;
otherwise, they alternate between north and east. When they fight, they always scratch.
They always appear as red and always eat. They always string %. */
 
import java.awt.*;
import java.util.*;

public class Ant extends Critter {
   private int stepCount; // the number of moves that the ant has taken
   private boolean walkSouth; // whether the ant goes to south or not
   
   // Constructs a new Ant
   // Parameters:
   //     boolean walkSouth - determines the direction of 
   //                         south or north ants will go
   public Ant(boolean walkSouth) {
      stepCount = -1; // the first step is counted as zero
      this.walkSouth = walkSouth;
   }
   
   // Ants return between south and east if walkSouth is true,
   // otherwise returning between north and east.
   public Direction getMove() {
      stepCount++;
      if (stepCount % 2 == 1) {
         return Direction.EAST;
      } else {
         if (walkSouth) {
            return Direction.SOUTH;
         } else {
            return Direction.NORTH;
         }
      }
   }

   // Ants always eat (returns true)      
   public boolean eat() {
      return true;
   }

   // Ants always scratch (returns Attack.SCRATCH)
   // Parameters:
   //     String opponent - the String representation of the opponent Critter
   public Attack fight(String opponent) {
      return Attack.SCRATCH;
   }

   // Ants are always red (returns RED)
   public Color getColor() {
      return Color.RED;
   }
   
   // Returns the percent sign
   public String toString() {
      return "%";
   }
}
