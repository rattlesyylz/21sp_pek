// Cynthia Hong
// 6/2/2021 
// CSE142
// TA: Ana Jojic
// Take-home Assessment #8
//
/* This class represents a Critter of type Hippo. When they move, 
they go Five (5) steps in a randomly chosen direction, then five (5) steps in another
randomly chosen direction, then repeat. When they fight, they scratch if still hungry;
otherwise, pounce. They appear as grey if hungry;otherwise, white.
They eat if still hungry. They string amount of remaining hunger.*/

import java.awt.*;
import java.util.*;

public class Hippo extends Critter {
   private Random rand; // to random pick up
   private int stepCount; // the number of moves that the hippo has taken
   private int hunger; // the times the hippo will eat 
   private int directionChoice; // the number to determine the direction choice
   
   // Constructs a new Hippo
   // Parameters:
   //     int hunger - determines the times the hippo will eat
   public Hippo(int hunger) {
      rand = new Random();
      stepCount = -1; // the first step is counted as zero
      this.hunger = hunger;
      directionChoice = 0; 
   }
   
   // Hippo go Five (5) steps in a randomly chosen direction, 
   // then five (5) steps in another randomly chosen direction, then repeat.
   // Returns the direction.
   public Direction getMove() {
      stepCount++;
      if (stepCount % 5 == 0) {
         directionChoice = rand.nextInt(4);  
      }
      if (directionChoice == 0) {
         return Direction.NORTH;
      } else if (directionChoice == 1) {
         return Direction.EAST;
      } else if (directionChoice == 2) {
         return Direction.SOUTH;
      } else { // (directionChoice == 3) 
         return Direction.WEST;
      }
   }

   // Hippos eat if still hungry, (returns TRUE);
   // otherwise, they do not eat (returns FALSE).
   public boolean eat() {
      if (hunger > 0) {
         hunger--;
         return true;
      } else {
         return false;
      }
   }
   
   // Roar if hippos still hungry; (returns Attack.SCRATCH)
   // otherwise, pounce. (returns Attack.POUNCE)
   // Parameters:
   //     String opponent - the String representation of the opponent Critter
   public Attack fight(String opponent) {
      if (hunger > 0) {
         return Attack.SCRATCH;
      } else {
         return Attack.POUNCE;
      }
   }
   
   // Hippos are appear as gray if hungry (returns GRAY);
   // otherwise, white (returns WHITE).
   public Color getColor() {
      if (hunger > 0) {
         return Color.GRAY;
      } else {
         return Color.WHITE;
      }
   }

   // Returns the amount of remaining hunger 
   public String toString() {
      return hunger + "";
   }
}
   

