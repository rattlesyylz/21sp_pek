// Cynthia Hong
// 6/2/2021 
// CSE142
// TA: Ana Jojic
// Take-home Assessment #8
//
/* This class represents a Critter of type Bird. When they move, they go 
North three (3) times, then east three (3) times, then south three (3) times,
then west three (3) times, then repeat. When they fight, Roar if opponent
looks like an ant ("%"); otherwise, pounce. They always appear as blue and never eat. 
They string "^" (caret) if last move was north, or never has never moved;
">" (greater than) if last move was east; "V" (uppercase V) if last move was south;
"<" (less than) if last move was west. */
 
import java.awt.*;
import java.util.*;

public class Bird extends Critter {
   private int stepCount; // the number of moves that the bird has taken

   // Constructs a new bied
   public Bird() {
      stepCount = -1; // the first step is counted as zero
   }
   
   // Birds return North three (3) times, then returning east three (3) times,
   // then returning south three (3) times, then returning west three (3) times,
   // then repeat.
   public Direction getMove() {
      stepCount++;
      if (stepCount % 12 < 3) {
         return Direction.NORTH;
      } else if (stepCount % 12 < 6) {
         return Direction.EAST;
      } else if (stepCount % 12 < 9) {
         return Direction.SOUTH;
      } else { 
         return Direction.WEST;
      }
   }

   // Roar if opponentlooks like an ant ("%"); (returns Attack.ROAR)
   // otherwise, pounce (returns Attack.POUNCE).
   // Parameters:
   //     String opponent - the String representation of the opponent Critter
   public Attack fight(String opponent) {
      if (opponent.equals("%")) {
         return Attack.ROAR;
      } else {
         return Attack.POUNCE;
      }
   }
   
   // omit the eat method because birds are never eat

   // Birds are always blue (returns BLUE)
   public Color getColor() {
      return Color.BLUE;
   }
   
   // Returns "^" (caret) if last move was north, or never has never moved;
   // returns ">" (greater than) if last move was east;
   // returns "V" (uppercase V) if last move was south;
   // returns "<" (less than) if last move was west.
   public String toString() {
      if (stepCount % 12 < 3 || stepCount == -1) {
         return "^";
      } else if (stepCount % 12 < 6) {
         return ">";
      } else if (stepCount % 12 < 9) {
         return "V";
      } else { 
         return "<";
      }
   }    
}
