// Cynthia Hong
// 5/18/2021 
// CSE142
// TA: Ana Jojic
// Take-home Assessment #4
//
/* This program, named YazInterpreter, will creat an interpreter for 
the programming language YazLang. As interpreting a YazLang file, 
the program propmts the user for input and output file names. 
Then the program reads and executes the YazLang commands in the input file 
and outputs the results to another file. The output file could be review 
or the program could be quitted.*/

import java.util.*;
import java.io.*;

public class YazInterpreter {
   public static void main(String[] args) throws FileNotFoundException {
      Scanner console = new Scanner(System.in);
      boolean test = true;
   
      giveIntro();
      while (test) {
         System.out.print("(I)nterpret YazLang program, (V)iew output, (Q)uit? ");
         String enterChoice = console.nextLine();
         if (enterChoice.equalsIgnoreCase("I")) {
            giveInterpret(console);
         } else if (enterChoice.equalsIgnoreCase("V")) {
            giveView(console);
         } else if (enterChoice.equalsIgnoreCase("Q")) {
            test = false;
         }  
      }
   }

   // prints out a short introduction as the beginning 
   // explains the purpose of the program
   public static void giveIntro() {
      System.out.println("Welcome to YazInterpreter!");
      System.out.println("You may interpret a YazLang program and output");
      System.out.println("the results to a file or view a previously");
      System.out.println("interpreted YazLang program.");
      System.out.println();
   }
 
   // produces the view part to read input file (name)
   // and prints out the context inside the input file
   //
   // scanner console - the scanner to use for input
   public static void giveView(Scanner console) throws FileNotFoundException {
      File fileName = inputFileName (console);
      System.out.println();  
      Scanner input = new Scanner(fileName);
      while (input.hasNextLine()) {
         String inputLine = input.nextLine(); 
         System.out.println(inputLine);
      } 
      System.out.println();    
   }
    
   // produces the interpret part to read input file (name)
   // and asks a name for output file and prints out such file
   //
   // scanner console - the scanner to use for input
   public static void giveInterpret(Scanner console) throws FileNotFoundException {
      File fileName = inputFileName(console);
      System.out.print("Output file name: ");
      String outputName = console.nextLine();
      PrintStream output = new PrintStream(new File(outputName));
      Scanner input = new Scanner(fileName);
      while (input.hasNextLine()) {
         Scanner tokens = new Scanner(input.nextLine());
         process(tokens, output);
      }
      System.out.println("YazLang interpreted and output to a file!");
      System.out.println();
   }
      
   // reads the beginning word of input file for each line
   // processes an tokens scanner
   // 
   // Scanner tokens - to read eachline of the input file
   // PrintStream output - where to direct output
   public static void process(Scanner tokens, PrintStream output) {
      String lineBegin = tokens.next();
      if (lineBegin.equals("CONVERT")) {
         giveConvert(tokens, output);
      } else if (lineBegin.equals("RANGE")) {
         giveRange(tokens, output);
      } else if (lineBegin.equals("REPEAT")) { 
         giveRepeat(tokens, output);
      }
   }

   // Computes and outputes a sequence of integers starting from arg1,
   // increasing by arg3, and ending with arg2
   // Tokens input will consist of the first interger(arg1,numberOne)
   // the second interger(arg2,numberTwo), and the third interger
   // (arg3,difference)
   //   
   // Scanner tokens - to read eachline of the input file
   // PrintStream output - where to direct output
   public static void giveRange(Scanner tokens, PrintStream output) {
      int numberOne = tokens.nextInt();
      int numberTwo = tokens.nextInt();
      int difference = tokens.nextInt();
      for (int i = numberOne; i < numberTwo; i += difference) {
         output.print(i + " ");
      } 
      output.println();   
   }  
   
   // Computes and outputes the converted temperature from Celsius to Fahrenheit
   // or vice versa using the formulas
   // Tokens input will consist of the temperture and unit
   //   
   // Scanner tokens - to read eachline of the input file
   // PrintStream output - where to direct output
   public static void giveConvert(Scanner tokens, PrintStream output) {
      int number = tokens.nextInt();
      String unit = tokens.next();
      if (unit.equalsIgnoreCase("C")) {
         output.println((int)(number * 1.8 + 32) + "F");
      } else {
         output.println((int)((number - 32) / 1.8) + "C");
      }
   }    
  
   // Computes and outputes the repeated times of the string argument
   // Tokens input will consist of the string argument and the number of time
   //   
   // Scanner tokens - to read eachline of the input file
   // PrintStream output - where to direct output
   public static void giveRepeat(Scanner tokens, PrintStream output) {
      String result = "";
      while (tokens.hasNext()) {
         String word = tokens.next();
         word = word.replace("_", " ");
         word = word.substring(1, word.length() - 1);
         int number = tokens.nextInt();
         for(int i = 0; i < number; i++) {
            result += word;
         }
      } 
      output.println(result);
   }   

   // Ruduces the redundancy of input the file name
   // and make sure the file exists
   // return the file
   //
   // scanner console - the scanner to use for input
   public static File inputFileName (Scanner console) throws FileNotFoundException {
      System.out.print("Input file name: ");
      File f = new File(console.nextLine());
      while (!f.exists()) {
         System.out.print("File not found. Try again: ");
         f = new File(console.nextLine());
      } 
      return f;
   }
}
